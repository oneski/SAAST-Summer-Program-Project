Evade: A Game by John Powell and David Silverman

Music: Main Song From Skywire by Nitrome, Musician: Lee Nicklen

Character Art: Inspired by Thin Ice from Nitrome

Background Art: Based on nitrome.com’s Winter Skin